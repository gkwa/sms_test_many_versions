/*****************************************************************
 *                 Time NSIS plugin v1.6                         *
 *                                                               *
 * 2006 Shengalts Aleksander aka Instructor (Shengalts@mail.ru)  *
 *****************************************************************/


/* Comment-out and recompile */
#define GETLOCALTIME    //Compile with GetLocalTime/GetLocalTimeUTC function
#define SETLOCALTIME    //Compile with SetLocalTime/SetLocalTimeUTC function
#define GETFILETIME     //Compile with GetFileTime/GetFileTimeUTC function
#define SETFILETIME     //Compile with SetFileTime/SetFileTimeUTC function
#define TIMESTRING      //Compile with TimeString function
#define MATHTIME        //Compile with MathTime function



#define WIN32_LEAN_AND_MEAN
#include <windows.h>

/* Defines */
#define MAX_STRLEN       1024
#define UNIT_UNKNOWN     -1
#define UNIT_SECOND      0
#define UNIT_MINUTE      1
#define UNIT_HOUR        2
#define UNIT_DAY         3
#define UNIT_MONTH       4
#define UNIT_YEAR        5
#define DATE_STRUCTURE   6

/* Include conversion functions */
#if defined SETLOCALTIME || defined SETFILETIME || defined TIMESTRING
	#define xatoi
#endif
#ifdef TIMESTRING
	#define xitoa
#endif
#ifdef MATHTIME
	#define xatoi64
	#define xi64toa
#endif
#include "ConvFunc.h"

/* NSIS stack structure */
typedef struct _stack_t {
	struct _stack_t *next;
	char text[MAX_STRLEN];
} stack_t;

stack_t **g_stacktop;
char *g_variables;
unsigned int g_stringsize;

#define EXDLL_INIT()            \
{                               \
	g_stacktop=stacktop;      \
	g_variables=variables;    \
	g_stringsize=string_size; \
}

/* Global variables */
char szBuf[MAX_STRLEN]="";
BOOL bUTC=FALSE;

#ifdef MATHTIME
	typedef struct TIME64 {
		__int64 nDay;
		__int64 nMonth;
		__int64 nYear;
		__int64 nHour;
		__int64 nMinute;
		__int64 nSecond;
	} TIME64;

	TIME64 lpTime64a;
	TIME64 lpTime64b;
#endif

/* Funtions prototypes and macros */
#if defined SETLOCALTIME || defined SETFILETIME || defined TIMESTRING
	BOOL ParseDateString(char *pString, SYSTEMTIME *lpSystemTime);
#endif
#ifdef GETFILETIME
	char* FileTimeToString(FILETIME *lpFileTime, char *szString, BOOL bUTC);
#endif
#ifdef SETFILETIME
	BOOL ParseFileTimeString(char *pString, FILETIME *lpFileTime, BOOL bUTC);
#endif
#ifdef MATHTIME
	BOOL ParseDateString64(char **pString, TIME64 *lpTime64);
	BOOL NormalizeStructure(TIME64 *lpTime64);
	__int64 StructureToUnit(int nUnit, TIME64 lpTime64);
	void UnitToStructure(int nUnit, TIME64 *lpTime64, __int64 nValue);
	void MathStructures(TIME64 *lpTime64a, TIME64 lpTime64b, char chOperator);
	void MathUnits(__int64 *nValueResult, __int64 nValue, char chOperator);
	BOOL GetConvertionUnit(char **pString, int *nUnit);
#endif
int popstring(char *str);
void pushstring(const char *str);

/* NSIS functions code */
#ifdef GETLOCALTIME
void __declspec(dllexport) _GetLocalTime(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
	SYSTEMTIME lpSystemTime={0};

	if (bUTC == FALSE)
		GetLocalTime(&lpSystemTime);
	else
		GetSystemTime(&lpSystemTime);

	wsprintf(szBuf, "%02d.%02d.%d %02d:%02d:%02d", lpSystemTime.wDay, lpSystemTime.wMonth, lpSystemTime.wYear, lpSystemTime.wHour, lpSystemTime.wMinute, lpSystemTime.wSecond);
	pushstring(szBuf);
  }
}

void __declspec(dllexport) _GetLocalTimeUTC(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
	bUTC=TRUE;
	_GetLocalTime(hwndParent, string_size, variables, stacktop);
	bUTC=FALSE;
}
#endif //GETLOCALTIME

#ifdef SETLOCALTIME
void __declspec(dllexport) _SetLocalTime(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
	SYSTEMTIME lpSystemTime={0};

	popstring(szBuf);

	if (ParseDateString(szBuf, &lpSystemTime))
	{
		if (bUTC == FALSE)
		{
			SetLocalTime(&lpSystemTime);
			SetLocalTime(&lpSystemTime);
		}
		else
		{
			SetSystemTime(&lpSystemTime);
			SetSystemTime(&lpSystemTime);
		}
		SendMessage(HWND_TOPMOST, WM_TIMECHANGE, 0, 0);
		pushstring("0");
	}
	else
		pushstring("-1");
  }
}

void __declspec(dllexport) _SetLocalTimeUTC(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
	bUTC=TRUE;
	_SetLocalTime(hwndParent, string_size, variables, stacktop);
	bUTC=FALSE;
}
#endif //SETLOCALTIME

#ifdef GETFILETIME
void __declspec(dllexport) _GetFileTime(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
	WIN32_FIND_DATA data={0};
	HANDLE hFind=NULL;
	int i;

	popstring(szBuf);

	if ((hFind=FindFirstFile(szBuf, &data)) != INVALID_HANDLE_VALUE && FindClose(hFind))
	{
		pushstring(FileTimeToString(&data.ftLastAccessTime, szBuf, bUTC));
		pushstring(FileTimeToString(&data.ftLastWriteTime, szBuf, bUTC));
		pushstring(FileTimeToString(&data.ftCreationTime, szBuf, bUTC));
		return;
	}
	for(i=0; i < 3; ++i) pushstring("");
  }
}

void __declspec(dllexport) _GetFileTimeUTC(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
	bUTC=TRUE;
	_GetFileTime(hwndParent, string_size, variables, stacktop);
	bUTC=FALSE;
}
#endif //GETFILETIME

#ifdef SETFILETIME
void __declspec(dllexport) _SetFileTime(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
	char szCreation[128];
	char szWrite[128];
	char szAccess[128];
	FILETIME ftCreationTime={0};
	FILETIME ftLastWriteTime={0};
	FILETIME ftLastAccessTime={0};
	HANDLE hFind=NULL;

	popstring(szBuf);
	popstring(szCreation);
	popstring(szWrite);
	popstring(szAccess);

	if ((hFind=CreateFile(szBuf, FILE_WRITE_ATTRIBUTES, 0, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL)) != INVALID_HANDLE_VALUE)
	{
		if (!ParseFileTimeString(szCreation, &ftCreationTime, bUTC) ||
			!ParseFileTimeString(szWrite, &ftLastWriteTime, bUTC) ||
			!ParseFileTimeString(szAccess, &ftLastAccessTime, bUTC) ||
			!SetFileTime(hFind, (*szCreation)?&ftCreationTime:NULL, (*szAccess)?&ftLastAccessTime:NULL, (*szWrite)?&ftLastWriteTime:NULL))
			goto error;

		CloseHandle(hFind);
		pushstring("0");
		return;
	}

	error:
	if (hFind != INVALID_HANDLE_VALUE) CloseHandle(hFind);
	pushstring("-1");
  }
}

void __declspec(dllexport) _SetFileTimeUTC(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
	bUTC=TRUE;
	_SetFileTime(hwndParent, string_size, variables, stacktop);
	bUTC=FALSE;
}
#endif //SETFILETIME

#ifdef TIMESTRING
void __declspec(dllexport) _TimeString(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
	SYSTEMTIME lpSystemTime={0};
	int i;

	popstring(szBuf);

	if (ParseDateString(szBuf, &lpSystemTime))
	{
		char tmp[128];
		pushstring(xitoa(lpSystemTime.wSecond, tmp, 0));
		pushstring(xitoa(lpSystemTime.wMinute, tmp, 0));
		pushstring(xitoa(lpSystemTime.wHour, tmp, 0));
		pushstring(xitoa(lpSystemTime.wYear, tmp, 0));
		pushstring(xitoa(lpSystemTime.wMonth, tmp, 0));
		pushstring(xitoa(lpSystemTime.wDay, tmp, 0));
	}
	else
		for(i=0; i < 6; ++i) pushstring("");
  }
}
#endif //TIMESTRING

#ifdef MATHTIME
void __declspec(dllexport) _MathTime(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  EXDLL_INIT();
  {
	__int64 nResultTmp=0;
	__int64 nResultSum=0;
	char *pBuf=&szBuf[0];
	char chCurrentOperator='\0';
	char chPreviousOperator='\0';
	int nUnit=UNIT_UNKNOWN;
	int nUnitTmp=UNIT_UNKNOWN;
	BOOL bNegative=FALSE;

	popstring(szBuf);

	while (*pBuf == ' ') ++pBuf;

	while (1)
	{
		if (GetConvertionUnit(&pBuf, &nUnitTmp))
		{
			if (nUnit != UNIT_UNKNOWN && nUnitTmp != nUnit) goto error;
			if (!ParseDateString64(&pBuf, &lpTime64b)) goto error;
			nUnit=nUnitTmp;
			if (nUnit != DATE_STRUCTURE)
			{
				if (!NormalizeStructure(&lpTime64b)) goto error;
				nResultTmp=StructureToUnit(nUnit, lpTime64b);
			}
		}
		else if (nUnit != DATE_STRUCTURE)
		{
			while (*pBuf == ' ') ++pBuf;

			if ((*pBuf >= '0' && *pBuf <= '9') || *pBuf == '-')
			{
				nResultTmp=xatoi64(pBuf);

				while (*++pBuf &&
					*pBuf != '=' &&
					*pBuf != '+' &&
					*pBuf != '-' &&
					*pBuf != '*' &&
					*pBuf != '/' &&
					*pBuf != '%');
			}
			else goto error;
		}
		else goto error;

		chCurrentOperator=*pBuf;
		++pBuf;

		if (nUnit != DATE_STRUCTURE)
			MathUnits(&nResultSum, nResultTmp, chPreviousOperator);
		else
			MathStructures(&lpTime64a, lpTime64b, chPreviousOperator);

		if (chCurrentOperator == '=')
		{
			while (*pBuf == ' ') ++pBuf;

			if (*pBuf != '\0')
			{
				if (nUnit == UNIT_UNKNOWN) goto error;
				if (!GetConvertionUnit(&pBuf, &nUnitTmp)) goto error;

				if (nUnitTmp == nUnit && nUnit == DATE_STRUCTURE)
				{
					if (!NormalizeStructure(&lpTime64a)) goto error;
				}
				else if (nUnitTmp != nUnit && nUnit == DATE_STRUCTURE)
				{
					if (!NormalizeStructure(&lpTime64a)) goto error;
					nResultSum=StructureToUnit(nUnitTmp, lpTime64a);
				}
				else if (nUnitTmp != nUnit && nUnitTmp == DATE_STRUCTURE)
				{
					UnitToStructure(nUnit, &lpTime64a, nResultSum);
					if (!NormalizeStructure(&lpTime64a)) goto error;
				}
				else if (nUnitTmp != nUnit)
				{
					if (nResultSum < 0)
					{
						nResultSum=0 - nResultSum;
						bNegative=TRUE;
					}
					UnitToStructure(nUnit, &lpTime64a, nResultSum);
					if (!NormalizeStructure(&lpTime64a)) goto error;
					nResultSum=StructureToUnit(nUnitTmp, lpTime64a);
					if (bNegative == TRUE) nResultSum=0 - nResultSum;
				}
				nUnit=nUnitTmp;
			}
		}

		chPreviousOperator=chCurrentOperator;
		if (chCurrentOperator == '\0') goto error;
		if (chCurrentOperator == '=') break;
	}

	if (nUnit != DATE_STRUCTURE)
	{
		xi64toa(nResultSum, szBuf, 0);
	}
	else
	{
		char tmp[128];
		lstrcpy(szBuf, xi64toa(lpTime64a.nDay, tmp, 2));
		lstrcat(szBuf, ".");
		lstrcat(szBuf, xi64toa(lpTime64a.nMonth, tmp, 2));
		lstrcat(szBuf, ".");
		lstrcat(szBuf, xi64toa(lpTime64a.nYear, tmp, 0));
		lstrcat(szBuf, " ");
		lstrcat(szBuf, xi64toa(lpTime64a.nHour, tmp, 2));
		lstrcat(szBuf, ":");
		lstrcat(szBuf, xi64toa(lpTime64a.nMinute, tmp, 2));
		lstrcat(szBuf, ":");
		lstrcat(szBuf, xi64toa(lpTime64a.nSecond, tmp, 2));
	}

	pushstring(szBuf);
	return;

	error:
	pushstring("");
  }
}
#endif //MATHTIME

void __declspec(dllexport) _Unload(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
}

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}


#if defined SETLOCALTIME || defined SETFILETIME || defined TIMESTRING
//Function: Fills SYSTEMTIME structure with the values from date string "31.12.2005 23:59:59"
BOOL ParseDateString(char *pString, SYSTEMTIME *lpSystemTime)
{
	int a=0;
	char chDelimiter;

	while (*pString)
	{
		if (*pString == '0')
		{
			while (*++pString == '0');
			--pString;
		}

		if (*pString >= '0' && *pString <= '9')
		{
			if (++a == 1)
				lpSystemTime->wDay=xatoi(pString);
			else if (a == 2 && chDelimiter == '.')
				lpSystemTime->wMonth=xatoi(pString);
			else if (a == 3 && chDelimiter == '.')
				lpSystemTime->wYear=xatoi(pString);
			else if (a == 4 && chDelimiter == ' ')
				lpSystemTime->wHour=xatoi(pString);
			else if (a == 5 && chDelimiter == ':')
				lpSystemTime->wMinute=xatoi(pString);
			else if (a == 6 && chDelimiter == ':')
			{
				lpSystemTime->wSecond=xatoi(pString);
				return TRUE;
			}
			else return FALSE;
		}
		else return FALSE;

		while (*pString && *pString >= '0' && *pString <= '9')
			++pString;

		chDelimiter=*pString++;

		while (a == 3 && *pString == ' ')
			++pString;
	}
	return FALSE;
}
#endif //SETLOCALTIME || SETFILETIME || TIMESTRING

#ifdef GETFILETIME
char* FileTimeToString(FILETIME *lpFileTime, char *szString, BOOL bUTC)
{
	SYSTEMTIME lpSystemTime={0};
	FILETIME lpLocalFileTime={0};

	if (bUTC == FALSE)
	{
		FileTimeToLocalFileTime(lpFileTime, &lpLocalFileTime);
		FileTimeToSystemTime(&lpLocalFileTime, &lpSystemTime);
	}
	else
		FileTimeToSystemTime(lpFileTime, &lpSystemTime);
	
	wsprintf(szString, "%02d.%02d.%d %02d:%02d:%02d", lpSystemTime.wDay, lpSystemTime.wMonth, lpSystemTime.wYear, lpSystemTime.wHour, lpSystemTime.wMinute, lpSystemTime.wSecond);
	return szString;
}
#endif //GETFILETIME

#ifdef SETFILETIME
//Function: Fills FILETIME structure with the values from date string "31.12.2005 23:59:59"
BOOL ParseFileTimeString(char *pString, FILETIME *lpFileTime, BOOL bUTC)
{
	SYSTEMTIME lpSystemTime={0};
	FILETIME lpLocalFileTime={0};

	if (*pString)
	{
		if (!ParseDateString(pString, &lpSystemTime))
			return FALSE;
	
		if (bUTC == FALSE)
		{
			if (!SystemTimeToFileTime(&lpSystemTime, &lpLocalFileTime) ||
				!LocalFileTimeToFileTime(&lpLocalFileTime, lpFileTime))
				 return FALSE;
		}
		else
		{
			if (!SystemTimeToFileTime(&lpSystemTime, lpFileTime))
				 return FALSE;
		}
	}
	return TRUE;
}
#endif //SETFILETIME

#ifdef MATHTIME
//Function: Fills TIME64 structure with the values from the first date in math string
//          and change pointer to the next operator (+,-,*,/,%,=)
//          "(31.12.2005 23:59:59) - date(31.12.2000 23:59:59) = date" -> "- date(31.12.2000 23:59:59) = date"
BOOL ParseDateString64(char **pString, TIME64 *lpTime64)
{
	int a=0;
	char chDelimiter;
	char *pBufTmp=*pString;

	if (*pBufTmp == '(') ++pBufTmp;
	else return FALSE;

	while (*pBufTmp)
	{
		if (*pBufTmp == '0')
		{
			while (*++pBufTmp == '0');
			--pBufTmp;
		}

		if (*pBufTmp >= '0' && *pBufTmp <= '9')
		{
			if (++a == 1)
				lpTime64->nDay=xatoi64(pBufTmp);
			else if (a == 2 && chDelimiter == '.')
				lpTime64->nMonth=xatoi64(pBufTmp);
			else if (a == 3 && chDelimiter == '.')
				lpTime64->nYear=xatoi64(pBufTmp);
			else if (a == 4 && chDelimiter == ' ')
				lpTime64->nHour=xatoi64(pBufTmp);
			else if (a == 5 && chDelimiter == ':')
				lpTime64->nMinute=xatoi64(pBufTmp);
			else if (a == 6 && chDelimiter == ':')
			{
				lpTime64->nSecond=xatoi64(pBufTmp);

				while (*pBufTmp && *pBufTmp >= '0' && *pBufTmp <= '9')
					++pBufTmp;

				if (*pBufTmp == ')')
				{
					while (*++pBufTmp &&
						*pBufTmp != '=' &&
						*pBufTmp != '+' &&
						*pBufTmp != '-' &&
						*pBufTmp != '*' &&
						*pBufTmp != '/' &&
						*pBufTmp != '%');

					*pString=pBufTmp;

					return TRUE;
				}
				return FALSE;
			}
			else return FALSE;
		}
		else return FALSE;

		while (*pBufTmp && *pBufTmp >= '0' && *pBufTmp <= '9')
			++pBufTmp;

		chDelimiter=*pBufTmp++;

		while (a == 3 && *pBufTmp == ' ')
			++pBufTmp;
	}
	return FALSE;
}

//Function: Get date unit of the first date in math string and
//          change pointer to the '(' or '\0' char
//          "date(31.12.2005 23:59:59)" -> "(31.12.2005 23:59:59)"
BOOL GetConvertionUnit(char **pString, int *nUnit)
{
	char szUnit[16];
	char *pStartUnitWord=NULL;
	char *pBuf=*pString;
	*nUnit=UNIT_UNKNOWN;

	while (*pBuf == ' ') ++pBuf;

	pStartUnitWord=pBuf;

	while (*pBuf &&
		*pBuf != '(' &&
		*pBuf != ')' &&
		*pBuf != ' ' &&
		*pBuf != '=' &&
		*pBuf != '+' &&
		*pBuf != '-' &&
		*pBuf != '*' &&
		*pBuf != '/' &&
		*pBuf != '%')
	{
		++pBuf;
	}

	if (!*pBuf || *pBuf == '(')
	{
		lstrcpyn(szUnit, pStartUnitWord, pBuf - pStartUnitWord + 1);

		if (!lstrcmpi(szUnit, "second"))
			*nUnit=UNIT_SECOND;
		else if (!lstrcmpi(szUnit, "minute"))
			*nUnit=UNIT_MINUTE;
		else if (!lstrcmpi(szUnit, "hour"))
			*nUnit=UNIT_HOUR;
		else if (!lstrcmpi(szUnit, "day"))
			*nUnit=UNIT_DAY;
		else if (!lstrcmpi(szUnit, "month"))
			*nUnit=UNIT_MONTH;
		else if (!lstrcmpi(szUnit, "year"))
			*nUnit=UNIT_YEAR;
		else if (!lstrcmpi(szUnit, "date"))
			*nUnit=DATE_STRUCTURE;
		else return FALSE;

		*pString=pBuf;
		return TRUE;
	}
	return FALSE;
}

//Function: Normalizes any irregular date structure
BOOL NormalizeStructure(TIME64 *lpTime64)
{
	__int64 nTmp=0;
	int a=0;
	int nYearCount=0;
	int days[12]={31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

	//Converts negative values to positive
	year:
	while (1)
		if (lpTime64->nYear >= 0 && lpTime64->nMonth <= 0)
		{
			lpTime64->nMonth+=12;
			--lpTime64->nYear;
			continue;
		}
		else if (lpTime64->nYear < 0) return FALSE;
		else break;

	month:
	while (1)
		if (lpTime64->nMonth > 0 && lpTime64->nDay <= 0)
		{
			if (lpTime64->nMonth == 1)
				lpTime64->nDay+=31;
			else
				lpTime64->nDay+=days[lpTime64->nMonth - 2];

			if (lpTime64->nMonth == 3 && (lpTime64->nYear == 0 || (lpTime64->nYear >= 4 && lpTime64->nYear % 4 == 0)))
				++lpTime64->nDay;
			--lpTime64->nMonth;
			continue;
		}
		else if (lpTime64->nMonth <= 0) goto year;
		else break;

	day:
	while (1)
		if (lpTime64->nDay > 0 && lpTime64->nHour < 0)
		{
			lpTime64->nHour+=24;
			--lpTime64->nDay;
			continue;
		}
		else if (lpTime64->nDay <= 0) goto month;
		else break;

	hour:
	while (1)
		if (lpTime64->nHour >= 0 && lpTime64->nMinute < 0)
		{
			lpTime64->nMinute+=60;
			--lpTime64->nHour;
			continue;
		}
		else if (lpTime64->nHour < 0) goto day;
		else break;

	while (1)
		if (lpTime64->nMinute >= 0 && lpTime64->nSecond < 0)
		{
			lpTime64->nSecond+=60;
			--lpTime64->nMinute;
			continue;
		}
		else if (lpTime64->nMinute < 0) goto hour;
		else break;


	//Normalize positive values
	//Seconds
	nTmp=lpTime64->nSecond/60;
	lpTime64->nSecond=lpTime64->nSecond%60;

	//Minutes
	lpTime64->nMinute+=nTmp;
	nTmp=lpTime64->nMinute/60;
	lpTime64->nMinute=lpTime64->nMinute%60;

	//Hours
	lpTime64->nHour+=nTmp;
	nTmp=lpTime64->nHour/24;
	lpTime64->nHour=lpTime64->nHour%24;

	//Days
	lpTime64->nDay+=nTmp;

	//Normalize months before days processing
	if (lpTime64->nMonth > 12)
	{
		if (lpTime64->nMonth % 12 == 0)
		{
			nTmp=lpTime64->nMonth/12 - 1;
			lpTime64->nMonth=12;
		}
		else
		{
			nTmp=lpTime64->nMonth/12;
			lpTime64->nMonth=lpTime64->nMonth%12;
		}
		lpTime64->nYear=lpTime64->nYear + nTmp;
	}

	if (lpTime64->nYear >= 4) nYearCount=(int)(lpTime64->nYear % 4);
	else nYearCount=(int)lpTime64->nYear;

	for(a=(int)(lpTime64->nMonth - 1); 1; a=0)
	{
		for (; a < 12; ++a)
		{
			nTmp=lpTime64->nDay - days[a];
			if (a == 1 && (nYearCount == 0 || (nYearCount >= 4 && nYearCount % 4 == 0)))
				--nTmp;

			if (nTmp > 0)
			{

				lpTime64->nDay=nTmp;
				++lpTime64->nMonth;
			}
			else break;
		}
		if (nTmp > 0) ++nYearCount;
		else break;
	}

	//Months after days processing
	if (lpTime64->nMonth > 12)
	{
		if (lpTime64->nMonth % 12 == 0)
		{
			nTmp=lpTime64->nMonth/12 - 1;
			lpTime64->nMonth=12;
		}
		else
		{
			nTmp=lpTime64->nMonth/12;
			lpTime64->nMonth=lpTime64->nMonth%12;
		}
	}
	else nTmp=0;

	//Years
	lpTime64->nYear=lpTime64->nYear + nTmp;

	return TRUE;
}

//Function: Converts normal date structure to the specified date unit
__int64 StructureToUnit(int nUnit, TIME64 lpTime64)
{
	__int64 nDaysBeforeYear=0;
	int nDaysBeforeMonth=0;

	if (nUnit == UNIT_SECOND || nUnit == UNIT_MINUTE || nUnit == UNIT_HOUR || nUnit == UNIT_DAY)
	{
		if (lpTime64.nMonth == 1) nDaysBeforeMonth=0;
		else if (lpTime64.nMonth == 2) nDaysBeforeMonth=31;
		else if (lpTime64.nMonth == 3) nDaysBeforeMonth=59;
		else if (lpTime64.nMonth == 4) nDaysBeforeMonth=90;
		else if (lpTime64.nMonth == 5) nDaysBeforeMonth=120;
		else if (lpTime64.nMonth == 6) nDaysBeforeMonth=151;
		else if (lpTime64.nMonth == 7) nDaysBeforeMonth=181;
		else if (lpTime64.nMonth == 8) nDaysBeforeMonth=212;
		else if (lpTime64.nMonth == 9) nDaysBeforeMonth=243;
		else if (lpTime64.nMonth == 10) nDaysBeforeMonth=273;
		else if (lpTime64.nMonth == 11) nDaysBeforeMonth=304;
		else if (lpTime64.nMonth == 12) nDaysBeforeMonth=334;

		if (lpTime64.nMonth > 2 && (lpTime64.nYear == 0 || (lpTime64.nYear >= 4 && lpTime64.nYear % 4 == 0)))
			++nDaysBeforeMonth;

		if (lpTime64.nYear == 0)
			nDaysBeforeYear=0;
		else
			nDaysBeforeYear=365*(lpTime64.nYear - ((lpTime64.nYear - 1)/4 + 1)) + 366*((lpTime64.nYear - 1)/4 + 1);
	}

	if (nUnit == UNIT_SECOND) return (lpTime64.nSecond + 60*lpTime64.nMinute + 3600*lpTime64.nHour + 86400*(lpTime64.nDay + nDaysBeforeMonth - 1) + 86400*nDaysBeforeYear);
	else if (nUnit == UNIT_MINUTE) return (lpTime64.nMinute + 60*lpTime64.nHour + 1440*(lpTime64.nDay + nDaysBeforeMonth - 1) + 1440*nDaysBeforeYear);
	else if (nUnit == UNIT_HOUR) return (lpTime64.nHour + 24*(lpTime64.nDay + nDaysBeforeMonth - 1) + 24*nDaysBeforeYear);
	else if (nUnit == UNIT_DAY) return ((lpTime64.nDay + nDaysBeforeMonth - 1) + nDaysBeforeYear);
	else if (nUnit == UNIT_MONTH) return (12*lpTime64.nYear + lpTime64.nMonth - 1);
	else if (nUnit == UNIT_YEAR) return (lpTime64.nYear);

	return 0;
}

//Function: Converts specified date unit to the date structure
void UnitToStructure(int nUnit, TIME64 *lpTime64, __int64 nValue)
{
	lpTime64->nYear=0;
	lpTime64->nMonth=1;
	lpTime64->nDay=1;
	lpTime64->nHour=0;
	lpTime64->nMinute=0;
	lpTime64->nSecond=0;

	if (nUnit == UNIT_SECOND)
		lpTime64->nSecond=nValue;
	else if (nUnit == UNIT_MINUTE)
		lpTime64->nMinute=nValue;
	else if (nUnit == UNIT_HOUR)
		lpTime64->nHour=nValue;
	else if (nUnit == UNIT_DAY)
		lpTime64->nDay=nValue + 1;
	else if (nUnit == UNIT_MONTH)
		lpTime64->nMonth=nValue + 1;
	else if (nUnit == UNIT_YEAR)
		lpTime64->nYear=nValue;
}

//Function: Arithmetic operation with two structures
void MathStructures(TIME64 *lpTime64a, TIME64 lpTime64b, char chOperator)
{
	if (chOperator == '+')
	{
		lpTime64a->nYear+=lpTime64b.nYear;
		lpTime64a->nMonth+=lpTime64b.nMonth;
		lpTime64a->nDay+=lpTime64b.nDay;
		lpTime64a->nHour+=lpTime64b.nHour;
		lpTime64a->nMinute+=lpTime64b.nMinute;
		lpTime64a->nSecond+=lpTime64b.nSecond;
	}
	else if (chOperator == '-')
	{
		lpTime64a->nYear-=lpTime64b.nYear;
		lpTime64a->nMonth-=lpTime64b.nMonth;
		lpTime64a->nDay-=lpTime64b.nDay;
		lpTime64a->nHour-=lpTime64b.nHour;
		lpTime64a->nMinute-=lpTime64b.nMinute;
		lpTime64a->nSecond-=lpTime64b.nSecond;
	}
	else if (chOperator == '*')
	{
		lpTime64a->nYear*=lpTime64b.nYear;
		lpTime64a->nMonth*=lpTime64b.nMonth;
		lpTime64a->nDay*=lpTime64b.nDay;
		lpTime64a->nHour*=lpTime64b.nHour;
		lpTime64a->nMinute*=lpTime64b.nMinute;
		lpTime64a->nSecond*=lpTime64b.nSecond;
	}
	else if (chOperator == '/')
	{
		lpTime64a->nYear/=lpTime64b.nYear;
		lpTime64a->nMonth/=lpTime64b.nMonth;
		lpTime64a->nDay/=lpTime64b.nDay;
		lpTime64a->nHour/=lpTime64b.nHour;
		lpTime64a->nMinute/=lpTime64b.nMinute;
		lpTime64a->nSecond/=lpTime64b.nSecond;
	}
	else if (chOperator == '%')
	{
		lpTime64a->nYear%=lpTime64b.nYear;
		lpTime64a->nMonth%=lpTime64b.nMonth;
		lpTime64a->nDay%=lpTime64b.nDay;
		lpTime64a->nHour%=lpTime64b.nHour;
		lpTime64a->nMinute%=lpTime64b.nMinute;
		lpTime64a->nSecond%=lpTime64b.nSecond;
	}
	else if (chOperator == '\0')
	{
		lpTime64a->nYear=lpTime64b.nYear;
		lpTime64a->nMonth=lpTime64b.nMonth;
		lpTime64a->nDay=lpTime64b.nDay;
		lpTime64a->nHour=lpTime64b.nHour;
		lpTime64a->nMinute=lpTime64b.nMinute;
		lpTime64a->nSecond=lpTime64b.nSecond;
	}
}

//Function: Arithmetic operation with two units
void MathUnits(__int64 *nValueResult, __int64 nValue, char chOperator)
{
	if (chOperator == '+')
		*nValueResult+=nValue;
	else if (chOperator == '-')
		*nValueResult-=nValue;
	else if (chOperator == '*')
		*nValueResult*=nValue;
	else if (chOperator == '/')
		*nValueResult/=nValue;
	else if (chOperator == '%')
		*nValueResult%=nValue;
	else if (chOperator == '\0')
		*nValueResult=nValue;
}
#endif //MATHTIME

//Function: Removes the element from the top of the NSIS stack and puts it in the buffer
int popstring(char *str)
{
	stack_t *th;
	if (!g_stacktop || !*g_stacktop) return 1;
	th=(*g_stacktop);
	lstrcpy(str,th->text);
	*g_stacktop = th->next;
	GlobalFree((HGLOBAL)th);
	return 0;
}

//Function: Adds an element to the top of the NSIS stack
void pushstring(const char *str)
{
	stack_t *th;
	if (!g_stacktop) return;
	th=(stack_t*)GlobalAlloc(GPTR,sizeof(stack_t)+g_stringsize);
	lstrcpyn(th->text,str,g_stringsize);
	th->next=*g_stacktop;
	*g_stacktop=th;
}
