Plugin for NSIS to write some logs at install time

Functionlist:
--------------

BDEAddStdAlias: creates a new standard alias on the system if it doesn't exists
Parameters:     filename (file to write the log in)
                text (the text that have to be written)
Call:           nsislog::log "c:\logfile.txt" "text to log"

error reporting or new ideas to
mayerbernd@gmx.net
